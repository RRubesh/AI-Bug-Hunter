import { Link, useNavigate } from "react-router-dom";
import { useState } from "react";

const Register = () => {
    const navigate = useNavigate();
    const [firstName, setFirstName] = useState('');
    const [lastName, setLastName] = useState('');
    const [email, setEmail] = useState('');
    const [phone, setPhone] = useState('');
    const [password, setPassword] = useState('');
    const [serviceType, setServiceType] = useState('');
    const [city, setCity] = useState('');
    const [address, setAddress] = useState('');
    const [experienceYears, setExperienceYears] = useState('');
    const [errorMsg, setErrorMsg] = useState('');

    const [photo, setPhoto] = useState(() => localStorage.getItem('ns_provider_photo') || "/assets/images/namma-service-logo.png");
    const [hasPhoto, setHasPhoto] = useState(() => !!localStorage.getItem('ns_provider_photo'));

    const handlePhotoUpload = (e) => {
        const file = e.target.files && e.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = function (ev) {
            const dataUrl = ev.target.result;
            setPhoto(dataUrl);
            setHasPhoto(true);
            localStorage.setItem('ns_provider_photo', dataUrl);
        };
        reader.readAsDataURL(file);
    };

    const handlePhotoRemove = () => {
        localStorage.removeItem('ns_provider_photo');
        setPhoto("/assets/images/namma-service-logo.png");
        setHasPhoto(false);
    };

    const handleRegister = async (e) => {
        e.preventDefault();
        setErrorMsg('');
        try {
            const res = await fetch('http://localhost:5000/api/auth/register', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    name: `${firstName} ${lastName}`.trim(),
                    email,
                    phone,
                    password,
                    role: 'provider',
                    providerDetails: {
                        serviceType,
                        city,
                        address,
                        experienceYears: Number(experienceYears)
                    }
                })
            });
            const data = await res.json();

            if (res.ok) {
                navigate('/login');
            } else {
                setErrorMsg(data.message || 'Registration failed');
            }
        } catch (err) {
            setErrorMsg('Network error. Is the server running?');
        }
    };

    return (
        <div className="container py-5">
            <div className="row justify-content-center">
                <div className="col-md-8 col-lg-6">
                    <div className="card shadow-lg border-0">
                        <div className="card-body p-5">
                            <h2 className="text-center fw-bold mb-4">Join Our Network</h2>
                            <p className="text-muted text-center mb-4">Are you a skilled professional? Register with us and get more customers!</p>

                            <form onSubmit={handleRegister}>
                                {errorMsg && <div className="alert alert-danger">{errorMsg}</div>}
                                <div className="row g-3">
                                    <div className="col-12 d-flex align-items-center gap-4 mb-2">
                                        <div className="text-center">
                                            <img src={photo} alt="Provider Photo" className="rounded-circle" style={{ width: "90px", height: "90px", objectFit: "cover", border: "2px solid #e9ecef" }} />
                                            <div className="mt-2">
                                                {hasPhoto && <button type="button" onClick={handlePhotoRemove} className="btn btn-sm btn-outline-danger">Remove</button>}
                                            </div>
                                        </div>
                                        <div className="flex-grow-1">
                                            <label className="form-label mb-1">Upload Your Photo / Logo</label>
                                            <input type="file" accept="image/*" onChange={handlePhotoUpload} className="form-control form-control-sm" />
                                            <small className="text-muted">Optional — JPG/PNG. Square images look best.</small>
                                        </div>
                                    </div>
                                    <div className="col-md-6">
                                        <label className="form-label">First Name</label>
                                        <input type="text" className="form-control" value={firstName} onChange={(e) => setFirstName(e.target.value)} required />
                                    </div>
                                    <div className="col-md-6">
                                        <label className="form-label">Last Name</label>
                                        <input type="text" className="form-control" value={lastName} onChange={(e) => setLastName(e.target.value)} required />
                                    </div>
                                    <div className="col-md-6">
                                        <label className="form-label">Email</label>
                                        <input type="email" className="form-control" value={email} onChange={(e) => setEmail(e.target.value)} required />
                                    </div>
                                    <div className="col-md-6">
                                        <label className="form-label">Password</label>
                                        <input type="password" className="form-control" value={password} onChange={(e) => setPassword(e.target.value)} required />
                                    </div>
                                    <div className="col-12">
                                        <label className="form-label">Service Type</label>
                                        <select className="form-select" required value={serviceType} onChange={(e) => setServiceType(e.target.value)}>
                                            <option value="" disabled>Choose Service...</option>
                                            <option value="Electrician">Electrician</option>
                                            <option value="Plumber">Plumber</option>
                                            <option value="Carpenter">Carpenter</option>
                                            <option value="AC Mechanic">AC Mechanic</option>
                                            <option value="Painter">Painter</option>
                                        </select>
                                    </div>
                                    <div className="col-12">
                                        <label className="form-label">Mobile Number</label>
                                        <input type="tel" className="form-control" placeholder="+91" value={phone} onChange={(e) => setPhone(e.target.value)} required />
                                    </div>
                                    <div className="col-12">
                                        <label className="form-label">Location (City)</label>
                                        <select className="form-select" required value={city} onChange={(e) => setCity(e.target.value)}>
                                            <option value="" disabled>Select City...</option>
                                            <option value="Chennai">Chennai</option>
                                            <option value="Madurai">Madurai</option>
                                            <option value="Coimbatore">Coimbatore</option>
                                            <option value="Trichy">Trichy</option>
                                        </select>
                                    </div>
                                    <div className="col-12">
                                        <label className="form-label">Full Address</label>
                                        <textarea className="form-control" rows="2" placeholder="e.g. 123 Main St, Anna Nagar" required value={address} onChange={(e) => setAddress(e.target.value)}></textarea>
                                    </div>
                                    <div className="col-12">
                                        <label className="form-label">Experience (Years)</label>
                                        <input type="number" className="form-control" min="0" value={experienceYears} onChange={(e) => setExperienceYears(e.target.value)} required />
                                    </div>
                                    <div className="col-12 mt-4">
                                        <button type="submit" className="btn btn-primary w-100 btn-lg fw-bold">Register Now</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div className="text-center mt-3">
                        <p className="text-muted">Already registered? <Link to="/login" className="text-primary text-decoration-none fw-bold">Login here</Link></p>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Register;
