import React from 'react'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Layout from './components/Layout'
import Home from './pages/Home'
import Login from './pages/Login'
import Register from './pages/Register'
import UserRegister from './pages/UserRegister'
import Dashboard from './pages/Dashboard'
import Profile from './pages/Profile'
import MyBookings from './pages/MyBookings'
import Services from './pages/Services'
import ProviderDetails from './pages/ProviderDetails'
import BookingDetails from './pages/BookingDetails'

import AdminLayout from './pages/admin/AdminLayout'
import AdminDashboard from './pages/admin/AdminDashboard'
import ManageUsers from './pages/admin/ManageUsers'
import ManageProviders from './pages/admin/ManageProviders'
import ManageBookings from './pages/admin/ManageBookings'

const App = () => {
  return (
    <BrowserRouter>
      <Routes>
        {/* Main Site Routes */}
        <Route path="/" element={<Layout />}>
          <Route index element={<Home />} />
          <Route path="login" element={<Login />} />
          <Route path="register" element={<Register />} />
          <Route path="user-register" element={<UserRegister />} />
          <Route path="dashboard" element={<Dashboard />} />
          <Route path="profile" element={<Profile />} />
          <Route path="my-bookings" element={<MyBookings />} />
          <Route path="services" element={<Services />} />
          <Route path="provider-details" element={<ProviderDetails />} />
          <Route path="booking-details" element={<BookingDetails />} />
        </Route>

        {/* Admin Interface Routes */}
        <Route path="/admin" element={<AdminLayout />}>
          <Route path="dashboard" element={<AdminDashboard />} />
          <Route path="users" element={<ManageUsers />} />
          <Route path="providers" element={<ManageProviders />} />
          <Route path="bookings" element={<ManageBookings />} />
        </Route>
      </Routes>
    </BrowserRouter>
  )
}

export default App
