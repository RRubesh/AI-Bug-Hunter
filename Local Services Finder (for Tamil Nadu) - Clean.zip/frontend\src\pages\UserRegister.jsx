import { Link, useNavigate } from "react-router-dom";
import { useState } from "react";

const UserRegister = () => {
    const navigate = useNavigate();
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [phone, setPhone] = useState('');
    const [password, setPassword] = useState('');
    const [errorMsg, setErrorMsg] = useState('');

    const handleRegister = async (e) => {
        e.preventDefault();
        setErrorMsg('');
        try {
            const res = await fetch('http://localhost:5000/api/auth/register', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name, email, phone, password, role: 'customer' })
            });
            const data = await res.json();

            if (res.ok) {
                // Auto login or redirect to login
                navigate('/login');
            } else {
                setErrorMsg(data.message || 'Registration failed');
            }
        } catch (err) {
            setErrorMsg('Network error. Is the server running?');
        }
    };

    return (
        <section className="py-5 d-flex align-items-center" style={{ minHeight: "100vh", paddingTop: "100px" }}>
            <div className="container pt-5">
                <div className="row justify-content-center">
                    <div className="col-md-8 col-lg-6">
                        <div className="card shadow-sm border-0 rounded-4">
                            <div className="card-body p-5">
                                <h2 className="text-center fw-bold mb-4">Register as a User</h2>
                                <p className="text-center text-muted mb-4">Join us and access multiple local services</p>
                                <form id="userRegisterForm" onSubmit={handleRegister}>
                                    {errorMsg && <div className="alert alert-danger">{errorMsg}</div>}
                                    <div className="mb-3">
                                        <div className="input-group">
                                            <span className="input-group-text"><i className="fas fa-user"></i></span>
                                            <input type="text" className="form-control form-control-lg" value={name} onChange={(e) => setName(e.target.value)} placeholder="Full Name" required />
                                        </div>
                                    </div>
                                    <div className="mb-3">
                                        <div className="input-group">
                                            <span className="input-group-text"><i className="fas fa-envelope"></i></span>
                                            <input type="email" className="form-control form-control-lg" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" required />
                                        </div>
                                    </div>
                                    <div className="mb-3">
                                        <div className="input-group">
                                            <span className="input-group-text"><i className="fas fa-phone"></i></span>
                                            <input type="tel" className="form-control form-control-lg" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="Phone Number" required />
                                        </div>
                                    </div>
                                    <div className="mb-3">
                                        <div className="input-group">
                                            <span className="input-group-text"><i className="fas fa-lock"></i></span>
                                            <input type="password" className="form-control form-control-lg" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password" required />
                                        </div>
                                    </div>

                                    <div className="d-grid mb-3">
                                        <button type="submit" className="btn btn-warning btn-lg fw-bold">Create Account</button>
                                    </div>
                                    <hr />
                                    <div className="text-center mt-3">
                                        <p className="text-muted mb-2">Or continue with</p>
                                        <div className="d-flex flex-column gap-2">
                                            <a href="#" target="_blank" rel="noopener noreferrer" className="btn btn-social btn-google"><span className="social-icon"><i className="fab fa-google"></i></span> Continue with Google</a>
                                            <a href="#" target="_blank" rel="noopener noreferrer" className="btn btn-social btn-apple"><span className="social-icon"><i className="fab fa-apple"></i></span> Continue with Apple</a>
                                            <a href="#" target="_blank" rel="noopener noreferrer" className="btn btn-social btn-microsoft"><span className="social-icon"><i className="fab fa-microsoft"></i></span> Continue with Microsoft</a>
                                        </div>
                                    </div>
                                    <div className="text-center mt-3">
                                        <p className="mb-0">Already have an account? <Link to="/login" className="text-primary text-decoration-none fw-bold">Login here</Link></p>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default UserRegister;
