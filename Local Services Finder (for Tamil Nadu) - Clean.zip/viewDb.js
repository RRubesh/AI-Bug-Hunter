const mongoose = require('mongoose');

// Mongoose Models
const UserSchema = new mongoose.Schema({}, { strict: false });
const ProviderSchema = new mongoose.Schema({}, { strict: false });
const BookingSchema = new mongoose.Schema({}, { strict: false });

const User = mongoose.model('User', UserSchema);
const Provider = mongoose.model('Provider', ProviderSchema);
const Booking = mongoose.model('Booking', BookingSchema);

const URI = 'mongodb://127.0.0.1:27017/local_services_finder';

const viewData = async () => {
    try {
        console.log("Connecting to MongoDB...");
        await mongoose.connect(URI);
        console.log("Connected successfully.\\n");

        console.log("=== USERS ===");
        const users = await User.find({});
        console.log(users.length === 0 ? "No users found" : JSON.stringify(users, null, 2));
        console.log("\\n");

        console.log("=== PROVIDERS ===");
        const providers = await Provider.find({});
        console.log(providers.length === 0 ? "No providers found" : JSON.stringify(providers, null, 2));
        console.log("\\n");

        console.log("=== BOOKINGS ===");
        const bookings = await Booking.find({});
        console.log(bookings.length === 0 ? "No bookings found" : JSON.stringify(bookings, null, 2));
        console.log("\\n");

    } catch (error) {
        console.error("Database Error:", error);
    } finally {
        await mongoose.connection.close();
        console.log("Connection closed.");
    }
};

viewData();
