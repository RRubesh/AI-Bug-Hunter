const express = require('express');
const router = express.Router();
const { registerUser, loginUser } = require('../controllers/authController');

router.post('/register', registerUser);
router.post('/login', loginUser);

// Placeholder routes for social OAuth providers.
// Implement with Passport or another OAuth library and configure client IDs/secrets in environment.
router.get('/google', (req, res) => {
	res.status(501).send(`
		<html>
			<head><title>Google OAuth</title></head>
			<body style="font-family:Arial,Helvetica,sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;">
				<div style="max-width:520px;padding:24px;border-radius:8px;border:1px solid #ddd;text-align:center;">
					<h2>Google OAuth Not Configured</h2>
					<p>This demo backend has no Google OAuth configured yet.</p>
					<p>To enable: set <strong>GOOGLE_CLIENT_ID</strong> and <strong>GOOGLE_CLIENT_SECRET</strong> in your environment and implement a Passport Google strategy.</p>
					<p><a href="/" style="color:#0d6efd">Return to API root</a></p>
				</div>
			</body>
		</html>
	`);
});

router.get('/google/callback', (req, res) => {
	res.status(501).send('<h1>Google OAuth callback not configured.</h1>');
});

router.get('/microsoft', (req, res) => {
	res.status(501).send(`
		<html>
			<head><title>Microsoft OAuth</title></head>
			<body style="font-family:Arial,Helvetica,sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;">
				<div style="max-width:520px;padding:24px;border-radius:8px;border:1px solid #ddd;text-align:center;">
					<h2>Microsoft OAuth Not Configured</h2>
					<p>To enable: set <strong>MICROSOFT_CLIENT_ID</strong> and <strong>MICROSOFT_CLIENT_SECRET</strong> and implement the Azure AD strategy.</p>
					<p><a href="/" style="color:#0d6efd">Return to API root</a></p>
				</div>
			</body>
		</html>
	`);
});

router.get('/microsoft/callback', (req, res) => {
	res.status(501).send('<h1>Microsoft OAuth callback not configured.</h1>');
});

router.get('/apple', (req, res) => {
	res.status(501).send(`
		<html>
			<head><title>Apple Sign In</title></head>
			<body style="font-family:Arial,Helvetica,sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;">
				<div style="max-width:520px;padding:24px;border-radius:8px;border:1px solid #ddd;text-align:center;">
					<h2>Apple Sign In Not Configured</h2>
					<p>To enable: implement the Passport-Apple strategy and set required Apple credentials in your environment.</p>
					<p><a href="/" style="color:#0d6efd">Return to API root</a></p>
				</div>
			</body>
		</html>
	`);
});

router.get('/apple/callback', (req, res) => {
	res.status(501).send('<h1>Apple Sign In callback not configured.</h1>');
});

module.exports = router;
