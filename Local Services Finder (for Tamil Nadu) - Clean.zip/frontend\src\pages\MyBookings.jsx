import { useState } from "react";
import { Link } from "react-router-dom";

const MyBookings = () => {
    const [bookings, setBookings] = useState(() => {
        const raw = localStorage.getItem('ns_bookings');
        if (raw) {
            try { return JSON.parse(raw); } catch { /* ignore parsing errors */ }
        }
        return [];
    });

    const addSampleBooking = () => {
        const newBooking = {
            id: Date.now().toString(36),
            service: 'Electrician',
            provider: 'Ramesh',
            date: new Date().toLocaleString(),
            status: 'Confirmed'
        };
        const updated = [...bookings, newBooking];
        setBookings(updated);
        localStorage.setItem('ns_bookings', JSON.stringify(updated));
    };

    return (
        <div className="container py-5 mt-5">
            <div className="row">
                <div className="col-12">
                    <h3 className="fw-bold">My Bookings</h3>
                    <p className="text-muted">Your upcoming and past bookings.</p>
                </div>
            </div>

            <div className="row">
                <div className="col-12">
                    <div className="card shadow-sm border-0 rounded-4">
                        <div className="card-body">
                            {bookings.length === 0 ? (
                                <div className="text-center text-muted py-4">
                                    <p>No bookings yet.</p>
                                    <button onClick={addSampleBooking} className="btn btn-sm btn-outline-primary">Add sample booking</button>
                                </div>
                            ) : (
                                <div className="table-responsive">
                                    <table className="table table-hover align-middle">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Service</th>
                                                <th>Provider</th>
                                                <th>Date</th>
                                                <th>Status</th>
                                                <th></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {bookings.map((b, i) => (
                                                <tr key={b.id}>
                                                    <td>{i + 1}</td>
                                                    <td>{b.service}</td>
                                                    <td>{b.provider}</td>
                                                    <td>{b.date}</td>
                                                    <td>{b.status}</td>
                                                    <td><Link className="btn btn-sm btn-outline-primary" to={`/booking-details?id=${b.id}`}>View</Link></td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default MyBookings;
