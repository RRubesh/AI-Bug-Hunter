import { Outlet, Link, useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";

const Layout = () => {
    const navigate = useNavigate();
    const [user, setUser] = useState(() => {
        const saved = localStorage.getItem('user');
        return saved ? JSON.parse(saved) : null;
    });

    useEffect(() => {
        const handleAuthChange = () => {
            const saved = localStorage.getItem('user');
            setUser(saved ? JSON.parse(saved) : null);
        };
        window.addEventListener('authStateChange', handleAuthChange);
        return () => window.removeEventListener('authStateChange', handleAuthChange);
    }, []);

    const handleLogout = () => {
        localStorage.removeItem('user');
        window.dispatchEvent(new Event('authStateChange'));
        navigate("/");
    };

    return (
        <>
            {/* Navigation */}
            <nav className="navbar navbar-expand-lg navbar-dark bg-primary fixed-top">
                <div className="container">
                    <Link className="navbar-brand fw-bold d-flex align-items-center" to="/">
                        <img src="/assets/images/namma-service-logo.png" alt="Namma Service Logo" className="me-2" height="40" />
                        <span className="brand-text">Namma Service</span>
                    </Link>
                    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="navbarNav">
                        <ul className="navbar-nav ms-auto">
                            <li className="nav-item"><Link className="nav-link active" to="/">Home</Link></li>
                            <li className="nav-item"><Link className="nav-link" to="/services">Services</Link></li>
                            <li className="nav-item"><Link className="nav-link" to="/register">Register as Provider</Link></li>
                            <li className="nav-item dropdown">
                                <a className="nav-link btn btn-primary text-white fw-bold ms-lg-3 px-3 rounded-pill dropdown-toggle" href="#" id="loginDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    <i className="fas fa-user-circle me-1"></i>{user ? user.name : "Login"}
                                </a>
                                <ul className="dropdown-menu dropdown-menu-end border-0 shadow-sm mt-2" aria-labelledby="loginDropdown">
                                    {user ? (
                                        <>
                                            {user.role === 'admin' && (
                                                <li><Link className="dropdown-item fw-bold text-danger" to="/admin/dashboard"><i className="fas fa-shield-alt me-2"></i>Admin Area</Link></li>
                                            )}
                                            <li><Link className="dropdown-item" to="/dashboard">Dashboard</Link></li>
                                            <li><Link className="dropdown-item" to="/profile">My Profile</Link></li>
                                            <li><Link className="dropdown-item" to="/my-bookings">My Bookings</Link></li>
                                            <li><hr className="dropdown-divider" /></li>
                                            <li><button className="dropdown-item text-danger" onClick={handleLogout}>Logout</button></li>
                                        </>
                                    ) : (
                                        <>
                                            <li><Link className="dropdown-item" to="/login">Sign In</Link></li>
                                            <li><Link className="dropdown-item" to="/user-register">Register as User</Link></li>
                                        </>
                                    )}
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>

            {/* Main Content */}
            <main>
                <Outlet />
            </main>

            {/* Footer */}
            <footer className="bg-dark text-white py-4 mt-auto">
                <div className="container text-center">
                    <div className="mb-3">
                        <Link to="#" className="text-white me-3 text-decoration-none">About Us</Link>
                        <Link to="#" className="text-white me-3 text-decoration-none">Terms & Conditions</Link>
                        <Link to="#" className="text-white text-decoration-none">Privacy Policy</Link>
                    </div>
                    <p className="mb-0">&copy; 2026 Namma Service. All rights reserved.</p>
                </div>
            </footer>
        </>
    );
};

export default Layout;
