Place the provided logo image here as `namma-service-logo.png`.

Filename: namma-service-logo.png
Path: assets/images/namma-service-logo.png

You can add the file by copying the attached image from your message into this path or by saving the image with that filename.

Recommended size: 120x40 or similar; keep the file type PNG for best results.