import { useState, useEffect } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";

const ProviderDetails = () => {
    const [searchParams] = useSearchParams();
    const id = searchParams.get("id");
    const navigate = useNavigate();

    const [provider, setProvider] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");

    // Booking form state
    const [problemDescription, setProblemDescription] = useState("");
    const [serviceAddress, setServiceAddress] = useState("");
    const [bookingError, setBookingError] = useState("");
    const [bookingSuccess, setBookingSuccess] = useState(false);

    useEffect(() => {
        const fetchProvider = async () => {
            try {
                const res = await fetch(`http://localhost:5000/api/providers/${id}`);
                const data = await res.json();
                if (res.ok) {
                    setProvider(data);
                } else {
                    setError(data.message || "Failed to load provider");
                }
            } catch (err) {
                setError("Network error. Server might be down.");
            } finally {
                setLoading(false);
            }
        };

        if (id) fetchProvider();
    }, [id]);

    const handleBookingSubmit = async (e) => {
        e.preventDefault();
        setBookingError("");
        setBookingSuccess(false);

        // Check auth manually from localStorage for now since we don't have full Context setup
        const userStr = localStorage.getItem("user");
        if (!userStr) {
            setBookingError("You must be logged in to book a service.");
            return;
        }

        const userObj = JSON.parse(userStr);
        if (!userObj.token) {
            setBookingError("Authentication required. Please log in again.");
            return;
        }

        try {
            const res = await fetch("http://localhost:5000/api/bookings", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${userObj.token}`
                },
                body: JSON.stringify({
                    providerId: provider._id,
                    service: provider.serviceType, // Using service string for now until we fully relationalize services
                    problemDescription,
                    serviceAddress
                })
            });

            const data = await res.json();
            if (res.ok) {
                setBookingSuccess(true);
                setProblemDescription("");
                setServiceAddress("");
            } else {
                setBookingError(data.message || "Booking failed");
            }
        } catch (err) {
            setBookingError("Network error. Please try again.");
        }
    };

    if (loading) {
        return (
            <div className="container py-5 mt-5 text-center">
                <div className="spinner-border text-primary" role="status">
                    <span className="visually-hidden">Loading...</span>
                </div>
            </div>
        );
    }

    if (error || !provider) {
        return (
            <div className="container py-5 mt-5">
                <div className="alert alert-danger shadow-sm border-0">{error || "Provider not found."}</div>
            </div>
        );
    }

    return (
        <div className="container py-5 mt-5">
            <div className="row">
                {/* Provider Info */}
                <div className="col-md-8">
                    <div className="card shadow-sm mb-4">
                        <div className="card-body">
                            <div className="d-flex align-items-center mb-4">
                                <img src="https://randomuser.me/api/portraits/men/32.jpg" className="rounded-circle me-4" alt="Provider" style={{ width: "100px", height: "100px", objectFit: "cover" }} />
                                <div>
                                    <h2 className="fw-bold mb-1">{provider.providerName || (provider.user ? provider.user.name : "Provider")}</h2>
                                    <p className="text-muted mb-0"><i className="fas fa-map-marker-alt me-2"></i>{provider.address}, {provider.city}</p>
                                    <div className="mt-2">
                                        <span className="badge bg-success me-2">{provider.averageRating > 0 ? provider.averageRating.toFixed(1) : "New"} <i className="fas fa-star text-warning"></i></span>
                                        <span className="text-muted">({provider.reviewCount || 0} Reviews)</span>
                                    </div>
                                </div>
                            </div>

                            <h5 className="fw-bold">About</h5>
                            <p className="text-muted">{provider.bio || `Experienced ${provider.serviceType} with ${provider.experienceYears} years of field experience.`}</p>

                            <h5 className="fw-bold mt-4">Services Offered</h5>
                            <ul className="list-unstyled text-muted">
                                <li><i className="fas fa-check-circle text-success me-2"></i>{provider.serviceType} Expert</li>
                                <li><i className="fas fa-check-circle text-success me-2"></i>Home Visits & Consultations</li>
                            </ul>
                        </div>
                    </div>

                    {/* Reviews */}
                    <div className="card shadow-sm">
                        <div className="card-header bg-white fw-bold">Recent Reviews</div>
                        <div className="card-body">
                            <div className="mb-3 border-bottom pb-2">
                                <div className="d-flex justify-content-between">
                                    <strong>Priya S.</strong>
                                    <span className="text-warning"><i className="fas fa-star"></i><i className="fas fa-star"></i><i className="fas fa-star"></i><i className="fas fa-star"></i><i className="fas fa-star"></i></span>
                                </div>
                                <p className="text-muted mb-0">Excellent service! Arrived on time and fixed the issue quickly.</p>
                            </div>
                            <div className="mb-3">
                                <div className="d-flex justify-content-between">
                                    <strong>Kumar R.</strong>
                                    <span className="text-warning"><i className="fas fa-star"></i><i className="fas fa-star"></i><i className="fas fa-star"></i><i className="fas fa-star"></i><i className="far fa-star"></i></span>
                                </div>
                                <p className="text-muted mb-0">Good work, but slightly expensive.</p>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Booking Section */}
                <div className="col-md-4">
                    <div className="card shadow-sm">
                        <div className="card-body">
                            <h4 className="fw-bold mb-3">Book Service</h4>
                            <p className="text-muted">Visiting Charge: <strong className="text-dark">₹{provider.visitingCharge || 250}</strong></p>
                            <div className="d-grid gap-2">
                                <button className="btn btn-primary btn-lg" data-bs-toggle="modal" data-bs-target="#bookingModal">Request Service</button>
                                {provider.phone && <a href={`https://wa.me/91${provider.phone}`} target="_blank" rel="noopener noreferrer" className="btn btn-outline-success btn-lg"><i className="fab fa-whatsapp me-2"></i>Chat on WhatsApp</a>}
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Booking Modal */}
            <div className="modal fade" id="bookingModal" tabIndex="-1" aria-hidden="true">
                <div className="modal-dialog">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title fw-bold">Request Service</h5>
                            <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div className="modal-body">
                            <form id="bookingForm" onSubmit={handleBookingSubmit}>
                                {bookingError && <div className="alert alert-danger">{bookingError}</div>}
                                {bookingSuccess && <div className="alert alert-success">Booking requested successfully! The provider will contact you soon.</div>}
                                <div className="mb-3">
                                    <label className="form-label">Selected Provider</label>
                                    <input type="text" className="form-control" value={provider.providerName || (provider.user && provider.user.name) || "Provider"} disabled />
                                </div>
                                <div className="mb-3">
                                    <label className="form-label">Service Type</label>
                                    <input type="text" className="form-control" value={provider.serviceType} disabled />
                                </div>
                                <div className="mb-3">
                                    <label className="form-label">Issue Description</label>
                                    <textarea className="form-control" rows="3" placeholder="Briefly describe the issue..." required value={problemDescription} onChange={(e) => setProblemDescription(e.target.value)}></textarea>
                                </div>
                                <div className="mb-3">
                                    <label className="form-label">Service Address</label>
                                    <textarea className="form-control" rows="2" placeholder="Your full address..." required value={serviceAddress} onChange={(e) => setServiceAddress(e.target.value)}></textarea>
                                </div>
                                <div className="modal-footer px-0 pb-0 border-0">
                                    <button type="button" className="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                    <button type="submit" className="btn btn-primary" disabled={bookingSuccess}>Submit Request</button>
                                </div>
                            </form>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    );
};

export default ProviderDetails;
