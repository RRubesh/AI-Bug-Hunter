/* script.js */

document.addEventListener('DOMContentLoaded', function () {
    console.log('Local Services Finder Loaded');

    // --- Services Page Filtering Logic ---
    const providerCards = document.querySelectorAll('.provider-card');
    const locationFilter = document.getElementById('locationFilter');
    const serviceFilter = document.getElementById('serviceFilter');
    const filterForm = document.querySelector('form.card-body'); // Assuming the filter sidebar is this form

    if (providerCards.length > 0) {
        // Function to filter providers
        function filterProviders() {
            const locValue = locationFilter ? locationFilter.value.toLowerCase() : '';
            const servValue = serviceFilter ? serviceFilter.value.toLowerCase() : '';

            providerCards.forEach(card => {
                const text = card.textContent.toLowerCase();
                const matchesLoc = locValue === 'select city...' || locValue === '' || text.includes(locValue);
                // Simple check: looking for service keywords in the card text
                let matchesServ = true;
                if (servValue && servValue !== 'choose service...') {
                    matchesServ = text.includes(servValue);
                }

                if (matchesLoc && matchesServ) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        }

        // Apply filters on button click
        if (filterForm) {
            filterForm.addEventListener('submit', function (e) {
                e.preventDefault();
                filterProviders();
            });
        }

        // Also check URL parameters on load
        const urlParams = new URLSearchParams(window.location.search);
        const locParam = urlParams.get('location');
        const servParam = urlParams.get('service'); // from search bar if we add name='service'

        if (locParam && locationFilter) {
            locationFilter.value = locParam;
            // We might need to match the value exactly to the option value
            // (e.g. 'Chennai' vs 'chennai') - let's try to set it.
            Array.from(locationFilter.options).forEach(opt => {
                if (opt.value.toLowerCase() === locParam.toLowerCase()) {
                    locationFilter.value = opt.value;
                }
            });
        }

        // Initial filter run if params exist
        if (locParam || servParam) filterProviders();
    }

    // --- Search Bar Logic (Index & Navbar) ---
    // We need to ensure the search bar inputs have names so they appear in URL if we used GET, 
    // but here we are intercepting submission.
    const searchForms = document.querySelectorAll('.d-flex[role="search"], .search-bar'); // Targeting navbar search if exists, and hero search

    searchForms.forEach(form => {
        form.addEventListener('submit', function (e) {
            e.preventDefault();
            // Try to find inputs. Structure might differ.
            const select = form.querySelector('select');
            const input = form.querySelector('input');

            let loc = select ? select.value : '';
            let q = input ? input.value : '';

            // Redirect
            window.location.href = `services.html?location=${encodeURIComponent(loc)}&service=${encodeURIComponent(q)}`;
        });
    });


    // --- Booking Logic (Mock) ---
    // Handle "Book Now" buttons to open modal (Bootstrap handles opening, we handle data prep if needed)
    const bookButtons = document.querySelectorAll('.btn-book');
    bookButtons.forEach(btn => {
        btn.addEventListener('click', function () {
            // In a real app, we'd pre-fill the modal with the provider's name
            // For now, it just opens the static modal
        });
    });

    // Handle Modal "Submit"
    const submitBookingBtn = document.querySelector('#bookingModal .btn-primary');
    if (submitBookingBtn) {
        submitBookingBtn.addEventListener('click', function () {
            // Dismiss modal
            const modalEl = document.getElementById('bookingModal');
            const modal = bootstrap.Modal.getInstance(modalEl);

            // Show success message
            alert('Booking Request Sent Successfully! The provider will contact you shortly.');

            if (modal) {
                modal.hide();
            }

            // clear form?
            const form = modalEl.querySelector('form');
            if (form) form.reset();
        });
    }

    // --- Login Logic ---
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', function (e) {
            e.preventDefault();
            // Mock login successful redirect
            window.location.href = 'dashboard.html';
        });
    }

    // --- User Registration Logic ---
    const userRegisterForm = document.getElementById('userRegisterForm');
    if (userRegisterForm) {
        userRegisterForm.addEventListener('submit', async function (e) {
            e.preventDefault();

            const fullNameEl = document.getElementById('fullName');
            const emailEl = document.getElementById('email');
            const phoneEl = document.getElementById('phone');
            const serviceTypeEl = document.getElementById('serviceType');

            const fullName = fullNameEl ? fullNameEl.value.trim() : '';
            const email = emailEl ? emailEl.value.trim() : '';
            const phone = phoneEl ? phoneEl.value.trim() : '';
            const serviceType = serviceTypeEl ? serviceTypeEl.value : '';

            if (!fullName || !email || !phone || !serviceType) {
                alert('Please fill all required fields.');
                return;
            }

            // split full name into first/last (simple heuristic)
            const parts = fullName.split(' ').filter(Boolean);
            const firstName = parts.length ? parts[0] : '';
            const lastName = parts.length > 1 ? parts.slice(1).join(' ') : '';

            // use a generated password if none provided (backend expects password)
            const generatedPassword = Math.random().toString(36).slice(-10);

            try {
                const res = await fetch('http://localhost:5000/api/auth/register', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ firstName, lastName, email, phone, password: generatedPassword, providerDetails: { serviceType } })
                });

                if (res.ok) {
                    const data = await res.json();
                    if (data.token) localStorage.setItem('authToken', data.token);
                    window.location.href = 'dashboard.html';
                } else {
                    const err = await res.json().catch(() => ({}));
                    alert(err.message || 'Registration failed.');
                }
            } catch (error) {
                console.error('Registration error:', error);
                alert('Could not connect to the server. Please try again later.');
            }
        });
    }

    // --- Dashboard Map & Geolocation Logic ---
    const mapElement = document.getElementById('dashboardMap');
    if (mapElement) {
        // Default coordinates (Chennai) in case geolocation fails
        const defaultLat = 13.0827;
        const defaultLng = 80.2707;

        // Initialize map
        const map = L.map('dashboardMap').setView([defaultLat, defaultLng], 11);

        // Add OpenStreetMap tiles
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }).addTo(map);

        // Custom icons
        const userIcon = L.icon({
            iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-red.png',
            shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
            iconSize: [25, 41],
            iconAnchor: [12, 41],
            popupAnchor: [1, -34],
            shadowSize: [41, 41]
        });

        const providerIcon = L.icon({
            iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-blue.png',
            shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
            iconSize: [25, 41],
            iconAnchor: [12, 41],
            popupAnchor: [1, -34],
            shadowSize: [41, 41]
        });

        let providerMarkers = [];

        // Mock providers data
        const mockProviders = [
            { name: "Ramesh Electric Works", type: "Electrician", rating: 4.8, img: "https://randomuser.me/api/portraits/men/32.jpg" },
            { name: "Suresh Plumbing Services", type: "Plumber", rating: 4.5, img: "https://randomuser.me/api/portraits/men/45.jpg" },
            { name: "Kumar AC Service", type: "AC Mechanic", rating: 4.2, img: "https://randomuser.me/api/portraits/men/88.jpg" },
            { name: "WoodArt Carpentry", type: "Carpenter", rating: 4.9, img: "https://randomuser.me/api/portraits/men/22.jpg" },
            { name: "Mani Electrician", type: "Electrician", rating: 4.0, img: "https://randomuser.me/api/portraits/men/11.jpg" }
        ];

        function showNearbyProviders(lat, lng) {
            // Clear existing markers
            providerMarkers.forEach(m => map.removeLayer(m.marker));
            providerMarkers = [];

            const listContainer = document.getElementById('nearbyProvidersList');
            if (listContainer) {
                listContainer.innerHTML = '';
            }

            // Generate mock providers near the location
            mockProviders.forEach((p, index) => {
                // Scatter them slightly around the user location
                const pLat = lat + (Math.random() - 0.5) * 0.05;
                const pLng = lng + (Math.random() - 0.5) * 0.05;

                const marker = L.marker([pLat, pLng], { icon: providerIcon }).addTo(map)
                    .bindPopup(`<b>${p.name}</b><br>${p.type} <br>⭐ ${p.rating}`);

                providerMarkers.push({ marker: marker, type: p.type.toLowerCase(), data: p });

                // Add to list
                if (listContainer) {
                    const li = document.createElement('li');
                    li.className = `list-group-item p-3 provider-list-item`;
                    li.dataset.type = p.type.toLowerCase();
                    li.innerHTML = `
                        <div class="d-flex align-items-center">
                            <img src="${p.img}" class="rounded-circle me-3" width="50" height="50" alt="${p.name}">
                            <div>
                                <h6 class="mb-1 fw-bold">${p.name}</h6>
                                <p class="mb-0 text-muted small"><i class="fas fa-tools me-1"></i>${p.type} <span class="ms-2 text-warning"><i class="fas fa-star"></i> ${p.rating}</span></p>
                            </div>
                        </div>
                    `;
                    listContainer.appendChild(li);
                }
            });
        }

        function filterProvidersBytype(type) {
            const listItems = document.querySelectorAll('.provider-list-item');

            providerMarkers.forEach(pm => {
                if (type === 'all' || pm.type === type) {
                    if (!map.hasLayer(pm.marker)) map.addLayer(pm.marker);
                } else {
                    if (map.hasLayer(pm.marker)) map.removeLayer(pm.marker);
                }
            });

            listItems.forEach(li => {
                if (type === 'all' || li.dataset.type === type) {
                    li.style.display = 'block';
                } else {
                    li.style.display = 'none';
                }
            });
        }

        const filterSelect = document.getElementById('nearbyServiceFilter');
        if (filterSelect) {
            filterSelect.addEventListener('change', (e) => {
                filterProvidersBytype(e.target.value);
            });
        }

        // Try Geolocation
        if ("geolocation" in navigator) {
            navigator.geolocation.getCurrentPosition(
                function (position) {
                    const userLat = position.coords.latitude;
                    const userLng = position.coords.longitude;

                    // Set map view to user location
                    map.setView([userLat, userLng], 13);

                    // Add user marker
                    userMarker = L.marker([userLat, userLng], { icon: userIcon }).addTo(map)
                        .bindPopup('<b>You are here</b>').openPopup();

                    // Show nearby providers based on user location
                    showNearbyProviders(userLat, userLng);

                },
                function (error) {
                    console.error("Geolocation error:", error);
                    document.getElementById('locationAlert').classList.remove('d-none');
                    // Fallback to default location
                    showNearbyProviders(defaultLat, defaultLng);
                },
                {
                    enableHighAccuracy: true,
                    timeout: 5000,
                    maximumAge: 0
                }
            );
        } else {
            console.warn("Geolocation not supported by this browser.");
            document.getElementById('locationAlert').classList.remove('d-none');
            showNearbyProviders(defaultLat, defaultLng);
        }
    }

});
