const mongoose = require('mongoose');

const providerSchema = new mongoose.Schema({
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true,
        unique: true
    },
    providerName: { type: String, required: true },
    serviceType: { type: String, required: true }, // e.g., electrician, plumber
    experienceYears: { type: Number, required: true },
    bio: { type: String },
    visitingCharge: { type: Number },
    contactDetails: {
        phone: { type: String },
        email: { type: String }
    },
    address: { type: String, required: true },
    location: {
        // GeoJSON format for geospatial queries
        type: {
            type: String,
            enum: ['Point'],
            required: false,
            default: 'Point'
        },
        coordinates: {
            type: [Number], // [longitude, latitude]
            required: false,
            default: [0, 0]
        }
    },
    city: { type: String },
    availabilityStatus: {
        type: String,
        enum: ['Available', 'Busy', 'Offline'],
        default: 'Available'
    },
    averageRating: { type: Number, default: 0 },
    reviewCount: { type: Number, default: 0 },
    createdAt: { type: Date, default: Date.now }
});

// Create a 2dsphere index on the location field for $near queries
providerSchema.index({ location: '2dsphere' });

module.exports = mongoose.model('Provider', providerSchema);
