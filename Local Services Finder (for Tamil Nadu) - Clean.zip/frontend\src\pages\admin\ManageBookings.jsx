import React, { useState, useEffect } from 'react';

const ManageBookings = () => {
    const [bookings, setBookings] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');

    useEffect(() => {
        const fetchBookings = async () => {
            const userStr = localStorage.getItem('user');
            if (!userStr) return;
            const adminUser = JSON.parse(userStr);

            try {
                const res = await fetch('http://localhost:5000/api/admin/bookings', {
                    headers: { 'Authorization': `Bearer ${adminUser.token}` }
                });

                if (res.ok) {
                    const data = await res.json();
                    setBookings(data);
                } else {
                    setError('Failed to fetch bookings');
                }
            } catch (err) {
                setError('Network error.');
            } finally {
                setLoading(false);
            }
        };

        fetchBookings();
    }, []);

    const getStatusBadge = (status) => {
        switch (status) {
            case 'Pending': return 'bg-warning text-dark';
            case 'Accepted': return 'bg-info text-dark';
            case 'Completed': return 'bg-success';
            case 'Cancelled': return 'bg-danger';
            default: return 'bg-secondary';
        }
    };

    if (loading) return <div className="text-center mt-5"><div className="spinner-border text-primary" role="status"></div></div>;
    if (error) return <div className="alert alert-danger">{error}</div>;

    return (
        <div className="bg-white rounded shadow-sm p-4">
            <h4 className="fw-bold mb-4">Manage Bookings</h4>
            <div className="table-responsive">
                <table className="table table-hover align-middle">
                    <thead className="table-light">
                        <tr>
                            <th>ID</th>
                            <th>Customer</th>
                            <th>Provider (Service)</th>
                            <th>Date Created</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        {bookings.map(b => (
                            <tr key={b._id}>
                                <td className="text-muted small">...{b._id.slice(-6)}</td>
                                <td>
                                    <div className="fw-bold">{b.user?.name || 'Unknown User'}</div>
                                    <div className="text-muted small">{b.user?.email}</div>
                                </td>
                                <td>
                                    <div className="fw-bold">{b.provider?.providerName || 'Unknown Provider'}</div>
                                    <div className="text-muted small">{b.service}</div>
                                </td>
                                <td>{new Date(b.createdAt).toLocaleDateString()}</td>
                                <td>
                                    <span className={`badge ${getStatusBadge(b.status)}`}>{b.status}</span>
                                </td>
                                <td>
                                    <button className="btn btn-sm btn-outline-primary" onClick={() => alert('View Details functionality coming soon!')}>
                                        <i className="fas fa-eye"></i> View
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                {bookings.length === 0 && <p className="text-center text-muted my-4">No bookings found.</p>}
            </div>
        </div>
    );
};

export default ManageBookings;
