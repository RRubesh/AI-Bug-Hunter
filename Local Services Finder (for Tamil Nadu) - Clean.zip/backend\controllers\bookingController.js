const Booking = require('../models/Booking');
const Provider = require('../models/Provider');

// @desc    Create a new booking
// @route   POST /api/bookings
// @access  Private (User)
exports.createBooking = async (req, res) => {
    try {
        const { providerId, service, problemDescription, serviceAddress, scheduledDate } = req.body;

        const booking = await Booking.create({
            user: req.user._id, // Set by authMiddleware
            provider: providerId,
            service,
            problemDescription,
            serviceAddress,
            scheduledDate,
            status: 'Pending'
        });

        res.status(201).json(booking);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error', error: error.message });
    }
};

// @desc    Get user bookings
// @route   GET /api/bookings/mybookings
// @access  Private
exports.getMyBookings = async (req, res) => {
    try {
        let query = {};
        if (req.user.role === 'provider') {
            const providerDoc = await Provider.findOne({ user: req.user._id });
            if (!providerDoc) {
                return res.status(404).json({ message: 'Provider profile not found' });
            }
            query = { provider: providerDoc._id };
        } else {
            query = { user: req.user._id };
        }

        const bookings = await Booking.find(query)
            .populate('user', 'name phone')
            .populate('provider', 'serviceType');

        res.json(bookings);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
};

// @desc    Update booking status
// @route   PUT /api/bookings/:id/status
// @access  Private (Provider/Admin)
exports.updateBookingStatus = async (req, res) => {
    try {
        const { status } = req.body;

        const booking = await Booking.findById(req.params.id);

        if (!booking) {
            return res.status(404).json({ message: 'Booking not found' });
        }

        booking.status = status || booking.status;
        const updatedBooking = await booking.save();

        res.json(updatedBooking);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
};
