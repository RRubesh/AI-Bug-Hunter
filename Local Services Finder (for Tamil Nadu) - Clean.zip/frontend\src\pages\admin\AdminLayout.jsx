import React from 'react';
import { Outlet, Navigate, Link, useNavigate, useLocation } from 'react-router-dom';

const AdminLayout = () => {
    const navigate = useNavigate();
    const location = useLocation();

    // Check if user is logged in and has admin role
    const userStr = localStorage.getItem('user');
    const user = userStr ? JSON.parse(userStr) : null;

    if (!user || user.role !== 'admin') {
        // Redirect non-admins to home
        return <Navigate to="/" replace />;
    }

    const handleLogout = () => {
        localStorage.removeItem('user');
        window.dispatchEvent(new Event('authStateChange'));
        navigate('/login');
    };

    const isActive = (path) => {
        return location.pathname === path ? 'active bg-primary text-white' : 'text-dark';
    };

    return (
        <div className="d-flex" style={{ minHeight: '100vh', backgroundColor: '#f4f6f9' }}>
            {/* Sidebar */}
            <div className="bg-white shadow-sm" style={{ width: '250px', position: 'fixed', height: '100vh', zIndex: 100 }}>
                <div className="p-4 border-bottom d-flex align-items-center justify-content-center">
                    <h4 className="fw-bold text-primary mb-0"><i className="fas fa-shield-alt me-2"></i>Admin Panel</h4>
                </div>
                <div className="p-3">
                    <div className="text-muted small fw-bold mb-3 text-uppercase">Core</div>
                    <ul className="nav flex-column mb-4">
                        <li className="nav-item mb-1">
                            <Link to="/admin/dashboard" className={`nav-link rounded ${isActive('/admin/dashboard')}`}>
                                <i className="fas fa-tachometer-alt me-2"></i> Dashboard
                            </Link>
                        </li>
                    </ul>
                    <div className="text-muted small fw-bold mb-3 text-uppercase">Management</div>
                    <ul className="nav flex-column">
                        <li className="nav-item mb-1">
                            <Link to="/admin/users" className={`nav-link rounded ${isActive('/admin/users')}`}>
                                <i className="fas fa-users me-2"></i> Users
                            </Link>
                        </li>
                        <li className="nav-item mb-1">
                            <Link to="/admin/providers" className={`nav-link rounded ${isActive('/admin/providers')}`}>
                                <i className="fas fa-user-tie me-2"></i> Providers
                            </Link>
                        </li>
                        <li className="nav-item mb-1">
                            <Link to="/admin/bookings" className={`nav-link rounded ${isActive('/admin/bookings')}`}>
                                <i className="fas fa-calendar-check me-2"></i> Bookings
                            </Link>
                        </li>
                    </ul>
                </div>
                <div className="p-3 border-top position-absolute bottom-0 w-100">
                    <button onClick={handleLogout} className="btn btn-outline-danger w-100">
                        <i className="fas fa-sign-out-alt me-2"></i>Logout
                    </button>
                    <Link to="/" className="btn btn-link text-decoration-none w-100 mt-2 text-muted">
                        <i className="fas fa-arrow-left me-2"></i>Back to Main Site
                    </Link>
                </div>
            </div>

            {/* Main Content Area */}
            <div style={{ marginLeft: '250px', width: 'calc(100% - 250px)' }}>
                {/* Admin Top Navbar */}
                <nav className="navbar navbar-light bg-white shadow-sm px-4 py-3">
                    <div className="container-fluid justify-content-end">
                        <div className="d-flex align-items-center">
                            <div className="me-3 text-end">
                                <span className="d-block fw-bold">{user.name}</span>
                                <span className="badge bg-danger">Administrator</span>
                            </div>
                            <img src="https://ui-avatars.com/api/?name=Admin&background=0D8ABC&color=fff" alt="Admin" className="rounded-circle" width="40" height="40" />
                        </div>
                    </div>
                </nav>

                {/* Page Content injected via Outlet */}
                <div className="p-4">
                    <Outlet />
                </div>
            </div>
        </div>
    );
};

export default AdminLayout;
