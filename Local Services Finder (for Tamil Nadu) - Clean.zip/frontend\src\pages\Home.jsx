import { Link } from "react-router-dom";

const Home = () => {
    return (
        <>
            {/* Hero Section */}
            <header className="hero-section d-flex align-items-center text-center text-white pt-5">
                <div className="container">
                    <h1 className="display-4 fw-bold mb-3">Find Trusted Local Services in Tamil Nadu</h1>
                    <p className="lead mb-4">Electricians, Plumbers, Carpenters & More - Just a Click Away!</p>

                    <div className="row justify-content-center">
                        <div className="col-md-6 d-flex justify-content-center gap-3">
                            <Link to="/login" className="btn btn-lg btn-outline-light px-4">Login</Link>
                            <Link to="/user-register" className="btn btn-lg btn-warning px-4 text-dark">Register</Link>
                        </div>
                    </div>
                </div>
            </header>

            {/* Popular Services */}
            <section className="py-5 bg-light">
                <div className="container">
                    <h2 className="text-center fw-bold mb-5">Popular Services</h2>
                    <div className="row g-4">
                        {/* Service Card 1 */}
                        <div className="col-md-3 col-sm-6">
                            <Link to="/services?category=electrician" className="card service-card h-100 text-decoration-none text-dark border-0 shadow-sm">
                                <div className="card-body text-center">
                                    <i className="fas fa-bolt fa-3x text-primary mb-3"></i>
                                    <h5 className="card-title">Electrician</h5>
                                    <p className="card-text text-muted">Wiring, Repairs, Installations</p>
                                </div>
                            </Link>
                        </div>
                        {/* Service Card 2 */}
                        <div className="col-md-3 col-sm-6">
                            <Link to="/services?category=plumber" className="card service-card h-100 text-decoration-none text-dark border-0 shadow-sm">
                                <div className="card-body text-center">
                                    <i className="fas fa-faucet fa-3x text-primary mb-3"></i>
                                    <h5 className="card-title">Plumber</h5>
                                    <p className="card-text text-muted">Leaks, Piping, Bathroom Fittings</p>
                                </div>
                            </Link>
                        </div>
                        {/* Service Card 3 */}
                        <div className="col-md-3 col-sm-6">
                            <Link to="/services?category=carpenter" className="card service-card h-100 text-decoration-none text-dark border-0 shadow-sm">
                                <div className="card-body text-center">
                                    <i className="fas fa-hammer fa-3x text-primary mb-3"></i>
                                    <h5 className="card-title">Carpenter</h5>
                                    <p className="card-text text-muted">Furniture, Doors, Windows</p>
                                </div>
                            </Link>
                        </div>
                        {/* Service Card 4 */}
                        <div className="col-md-3 col-sm-6">
                            <Link to="/services?category=ac" className="card service-card h-100 text-decoration-none text-dark border-0 shadow-sm">
                                <div className="card-body text-center">
                                    <i className="fas fa-snowflake fa-3x text-primary mb-3"></i>
                                    <h5 className="card-title">AC Mechanic</h5>
                                    <p className="card-text text-muted">Service, Repair, Installation</p>
                                </div>
                            </Link>
                        </div>
                    </div>
                </div>
            </section>

            {/* Why Choose Us */}
            <section className="py-5">
                <div className="container">
                    <h2 className="text-center fw-bold mb-5">Why Choose Namma Service?</h2>
                    <div className="row text-center">
                        <div className="col-md-4 mb-4">
                            <i className="fas fa-user-check fa-3x text-success mb-3"></i>
                            <h4>Verified Professionals</h4>
                            <p className="text-muted">All our providers are background checked and verified.</p>
                        </div>
                        <div className="col-md-4 mb-4">
                            <i className="fas fa-clock fa-3x text-warning mb-3"></i>
                            <h4>On-Time Service</h4>
                            <p className="text-muted">We value your time. Punctual service, every time.</p>
                        </div>
                        <div className="col-md-4 mb-4">
                            <i className="fas fa-rupee-sign fa-3x text-primary mb-3"></i>
                            <h4>Transparent Pricing</h4>
                            <p className="text-muted">No hidden costs. Pay for what you get.</p>
                        </div>
                    </div>
                </div>
            </section>
        </>
    );
};

export default Home;
