const express = require('express');
const router = express.Router();
const { getStats, getAllUsers, getAllProviders, getAllBookings } = require('../controllers/adminController');
const { protect } = require('../middleware/authMiddleware');
const { adminMiddleware } = require('../middleware/adminMiddleware');

// All routes require authentication AND admin privileges
router.use(protect);
router.use(adminMiddleware);

router.get('/stats', getStats);
router.get('/users', getAllUsers);
router.get('/providers', getAllProviders);
router.get('/bookings', getAllBookings);

module.exports = router;
