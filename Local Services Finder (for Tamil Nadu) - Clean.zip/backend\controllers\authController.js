const User = require('../models/User');
const Provider = require('../models/Provider');
const jwt = require('jsonwebtoken');

// Generate JWT
const generateToken = (id) => {
    return jwt.sign({ id }, process.env.JWT_SECRET, {
        expiresIn: '30d',
    });
};

// @desc    Register new user
// @route   POST /api/auth/register
// @access  Public
exports.registerUser = async (req, res) => {
    try {
        const { name, email, password, phone, role, providerDetails } = req.body;

        // Check if user exists
        const userExists = await User.findOne({ email });
        if (userExists) {
            return res.status(400).json({ message: 'User already exists' });
        }

        // Create user
        const user = await User.create({
            name,
            email,
            password,
            phone,
            role: role || 'customer'
        });

        if (user) {
            // If user is a provider, create provider profile
            if (user.role === 'provider' && providerDetails) {
                await Provider.create({
                    user: user._id,
                    providerName: providerDetails.providerName || name, // Fallback to user name
                    serviceType: providerDetails.serviceType,
                    experienceYears: providerDetails.experienceYears,
                    bio: providerDetails.bio,
                    visitingCharge: providerDetails.visitingCharge,
                    contactDetails: {
                        phone: providerDetails.phone || phone,
                        email: providerDetails.email || email
                    },
                    address: providerDetails.address || '',
                    location: providerDetails.location || { type: 'Point', coordinates: [0, 0] },
                    city: providerDetails.city
                });
            }

            res.status(201).json({
                _id: user._id,
                name: user.name,
                email: user.email,
                role: user.role,
                token: generateToken(user._id),
            });
        } else {
            res.status(400).json({ message: 'Invalid user data' });
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error', error: error.message });
    }
};

// @desc    Authenticate a user
// @route   POST /api/auth/login
// @access  Public
exports.loginUser = async (req, res) => {
    try {
        const { email, password } = req.body;

        // Check for user email
        const user = await User.findOne({ email });

        if (user && (await user.matchPassword(password))) {
            res.json({
                _id: user._id,
                name: user.name,
                email: user.email,
                role: user.role,
                token: generateToken(user._id),
            });
        } else {
            res.status(401).json({ message: 'Invalid email or password' });
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
};
