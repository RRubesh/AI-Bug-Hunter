const mongoose = require('mongoose');
const dotenv = require('dotenv');

// Load env vars
dotenv.config();

// Mongoose Models
const UserSchema = new mongoose.Schema({
    email: String,
    role: String
}, { strict: false });

const User = mongoose.model('User', UserSchema);

const URI = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/local_services_finder';

const promoteUser = async () => {
    try {
        console.log("Connecting to MongoDB...");
        await mongoose.connect(URI);
        console.log("Connected successfully.\\n");

        const targetEmail = process.argv[2] || "tester5@test.com";

        const user = await User.findOne({ email: targetEmail });

        if (!user) {
            console.log(`User with email ${targetEmail} not found!`);
        } else {
            console.log(`Found user: ${user.email} (Current Role: ${user.role})`);
            user.role = 'admin';
            await user.save();
            console.log(`\\nSUCCESS: User ${user.email} promoted to ADMIN!`);
        }
    } catch (error) {
        console.error("Database Error:", error);
    } finally {
        await mongoose.connection.close();
        console.log("Connection closed.");
    }
};

promoteUser();
