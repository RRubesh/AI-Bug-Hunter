import { Link, useNavigate } from "react-router-dom";
import { useState } from "react";

const Login = () => {
    const navigate = useNavigate();
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [errorMsg, setErrorMsg] = useState('');

    const handleLogin = async (e) => {
        e.preventDefault();
        setErrorMsg('');
        try {
            const res = await fetch('http://localhost:5000/api/auth/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password })
            });
            const data = await res.json();

            if (res.ok) {
                localStorage.setItem("user", JSON.stringify(data));
                window.dispatchEvent(new Event("authStateChange"));
                navigate("/dashboard");
            } else {
                setErrorMsg(data.message || 'Login failed');
            }
        } catch (err) {
            setErrorMsg('Network error. Is the server running?');
        }
    };

    return (
        <section className="py-5 d-flex align-items-center" style={{ minHeight: "100vh", paddingTop: "100px" }}>
            <div className="container pt-5">
                <div className="row justify-content-center">
                    <div className="col-md-8 col-lg-6">
                        <div className="card shadow-sm border-0 rounded-4">
                            <div className="card-body p-5">
                                <h3 className="text-center fw-bold mb-2">Login to Your Account</h3>
                                <p className="text-center text-muted mb-4">Access local services quickly and easily</p>

                                <form id="loginForm" onSubmit={handleLogin}>
                                    {errorMsg && <div className="alert alert-danger">{errorMsg}</div>}
                                    <div className="mb-3">
                                        <div className="input-group">
                                            <span className="input-group-text"><i className="fas fa-envelope"></i></span>
                                            <input type="email" className="form-control form-control-lg" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" required />
                                        </div>
                                    </div>

                                    <div className="mb-4">
                                        <div className="input-group">
                                            <span className="input-group-text"><i className="fas fa-lock"></i></span>
                                            <input type="password" className="form-control form-control-lg" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password" required />
                                        </div>
                                    </div>

                                    <div className="d-grid mb-3">
                                        <button type="submit" className="btn btn-warning btn-lg fw-bold">Login</button>
                                    </div>

                                    <div className="text-center mb-3"><Link to="#" className="text-muted">Forgot Password?</Link></div>

                                    <hr />

                                    <div className="text-center mt-3">
                                        <p className="text-muted mb-2">Or continue with</p>
                                        <div className="d-flex flex-column gap-2">
                                            <a href="#" className="btn btn-social btn-google"><span className="social-icon"><i className="fab fa-google"></i></span> Continue with Google</a>
                                            <a href="#" className="btn btn-social btn-apple"><span className="social-icon"><i className="fab fa-apple"></i></span> Continue with Apple</a>
                                            <a href="#" className="btn btn-social btn-microsoft"><span className="social-icon"><i className="fab fa-microsoft"></i></span> Continue with Microsoft</a>
                                        </div>
                                    </div>

                                    <div className="text-center mt-4">
                                        <small className="text-muted">New here? <Link to="/user-register" className="fw-bold">Register Now</Link></small>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default Login;
