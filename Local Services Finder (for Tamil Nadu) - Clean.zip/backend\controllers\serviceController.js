const Service = require('../models/Service');

// @desc    Get all active services
// @route   GET /api/services
// @access  Public
exports.getServices = async (req, res) => {
    try {
        const services = await Service.find({});
        res.json(services);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
};

// @desc    Create a new service category
// @route   POST /api/services
// @access  Private (Admin only - simplified for now)
exports.createService = async (req, res) => {
    try {
        const { name, category, description, basePrice } = req.body;

        const service = await Service.create({
            name,
            category,
            description,
            basePrice
        });

        res.status(201).json(service);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
};
