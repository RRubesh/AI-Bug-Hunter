const User = require('../models/User');
const Provider = require('../models/Provider');
const Booking = require('../models/Booking');

// @desc    Get dashboard statistics
// @route   GET /api/admin/stats
// @access  Private (Admin)
exports.getStats = async (req, res) => {
    try {
        const totalUsers = await User.countDocuments({ role: 'customer' });
        const totalProviders = await Provider.countDocuments();

        // Count bookings by status
        const pendingBookings = await Booking.countDocuments({ status: 'Pending' });
        const completedBookings = await Booking.countDocuments({ status: 'Completed' });
        const totalBookings = await Booking.countDocuments();

        // Calculate total revenue (assuming completed bookings have a cost)
        const completedBookingDocs = await Booking.find({ status: 'Completed' });
        const totalRevenue = completedBookingDocs.reduce((acc, booking) => acc + (booking.cost || 0), 0);

        res.json({
            users: totalUsers,
            providers: totalProviders,
            bookings: {
                total: totalBookings,
                pending: pendingBookings,
                completed: completedBookings
            },
            revenue: totalRevenue
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server Error fetching stats' });
    }
};

// @desc    Get all users
// @route   GET /api/admin/users
// @access  Private (Admin)
exports.getAllUsers = async (req, res) => {
    try {
        const users = await User.find({}).select('-password').sort({ createdAt: -1 });
        res.json(users);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server Error fetching users' });
    }
};

// @desc    Get all providers
// @route   GET /api/admin/providers
// @access  Private (Admin)
exports.getAllProviders = async (req, res) => {
    try {
        const providers = await Provider.find({}).populate('user', 'name email').sort({ createdAt: -1 });
        res.json(providers);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server Error fetching providers' });
    }
};

// @desc    Get all bookings
// @route   GET /api/admin/bookings
// @access  Private (Admin)
exports.getAllBookings = async (req, res) => {
    try {
        const bookings = await Booking.find({})
            .populate('user', 'name email')
            .populate('provider', 'providerName serviceType')
            .sort({ createdAt: -1 });
        res.json(bookings);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server Error fetching bookings' });
    }
};
