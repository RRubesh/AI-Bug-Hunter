const testIntegration = async () => {
    try {
        console.log("=== Testing Authentication & Provider APIs ===");

        // 1. Register a test user
        console.log("\n1. Registering customer...");
        const regCustomerReq = await fetch("http://localhost:5000/api/auth/register", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                name: "API Tester",
                email: "tester6@test.com",
                phone: "1112223333",
                password: "password123",
                role: "customer"
            })
        });
        const regCustomerRes = await regCustomerReq.json();
        console.log("Reg Customer:", regCustomerRes);

        // 2. Register a test provider
        console.log("\n2. Registering provider...");
        const regProviderReq = await fetch("http://localhost:5000/api/auth/register", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                name: "Test Plumber",
                email: "plumber6@test.com",
                phone: "5555555555",
                password: "password123",
                role: "provider",
                providerDetails: {
                    serviceType: "Plumber",
                    city: "Chennai",
                    address: "123 Test St",
                    experienceYears: 10
                }
            })
        });
        const regProviderRes = await regProviderReq.json();
        console.log("Reg Provider:", regProviderRes);

        // 3. Login as customer
        console.log("\n3. Logging in as customer...");
        const loginReq = await fetch("http://localhost:5000/api/auth/login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ email: "tester6@test.com", password: "password123" })
        });
        const loginData = await loginReq.json();
        console.log("Login Res:", loginData.name ? "Success" : "Failed");
        const token = loginData.token;

        // 4. Fetch all providers
        console.log("\n4. Fetching providers...");
        const provReq = await fetch("http://localhost:5000/api/providers");
        const providers = await provReq.json();
        console.log(`Found ${providers.length} providers`);

        let targetProviderId = null;
        if (providers.length > 0) {
            targetProviderId = providers[providers.length - 1]._id;
            console.log("Sample provider ID:", targetProviderId);
        }

        // 5. Test booking if we have a provider and token
        if (token && targetProviderId) {
            console.log("\n5. Creating a booking...");
            const bookReq = await fetch("http://localhost:5000/api/bookings", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${token}`
                },
                body: JSON.stringify({
                    providerId: targetProviderId,
                    service: "Plumber",
                    problemDescription: "API Test Booking",
                    serviceAddress: "System Check, Chennai"
                })
            });
            const bookRes = await bookReq.json();
            console.log("Booking result status:", bookReq.status);
            console.log("Booking res payload:", bookRes);
        }

    } catch (err) {
        console.error("Test blocked by connection error:", err.message);
    }
};

testIntegration();
