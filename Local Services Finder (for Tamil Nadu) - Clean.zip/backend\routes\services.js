const express = require('express');
const router = express.Router();
const { getServices, createService } = require('../controllers/serviceController');
// Note: In a real app, createService should trigger the auth/admin middleware.
// For now we will keep it simple.

router.route('/')
    .get(getServices)
    .post(createService);

module.exports = router;
