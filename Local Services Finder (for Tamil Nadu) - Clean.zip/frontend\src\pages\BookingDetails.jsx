import { Link, useSearchParams } from "react-router-dom";

const BookingDetails = () => {
    const [searchParams] = useSearchParams();
    const id = searchParams.get("id");

    let error = "";
    let booking = null;

    if (!id) {
        error = "No booking selected.";
    } else {
        const raw = localStorage.getItem('ns_bookings');
        const bookings = raw ? JSON.parse(raw) : [];
        booking = bookings.find(b => b.id === id);
        if (!booking) {
            error = "Booking not found.";
        }
    }

    return (
        <div className="container py-5 mt-5">
            <div className="row">
                <div className="col-md-8 mx-auto">
                    <div className="card shadow-sm border-0 rounded-4">
                        <div className="card-header bg-white border-0 py-4">
                            <h4 className="mb-0 fw-bold"><i className="fas fa-ticket-alt me-2 text-primary"></i>Booking Details</h4>
                        </div>
                        <div className="card-body">
                            {error ? (
                                <p className="text-danger">{error}</p>
                            ) : booking ? (
                                <>
                                    <h5 className="fw-bold">{booking.service}</h5>
                                    <p className="mb-1"><strong>Provider:</strong> {booking.provider}</p>
                                    <p className="mb-1"><strong>Date:</strong> {booking.date}</p>
                                    <p className="mb-3"><strong>Status:</strong> {booking.status}</p>
                                    <hr />
                                    <p className="text-muted">This is a placeholder details view. Replace with real booking fields from the backend.</p>
                                </>
                            ) : (
                                <p className="text-muted">Loading booking details...</p>
                            )}
                        </div>
                        <div className="card-footer bg-white">
                            <Link to="/my-bookings" className="btn btn-outline-secondary">Back to Bookings</Link>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default BookingDetails;
