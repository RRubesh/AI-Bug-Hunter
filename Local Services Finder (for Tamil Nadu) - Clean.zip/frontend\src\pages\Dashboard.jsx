import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { MapContainer, TileLayer, Marker, Popup, useMap } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import L from "leaflet";

// Fix for default marker icons in React Leaflet
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
    iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
    iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
    shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png"
});

// Component to recenter map when location changes
const RecenterMap = ({ location }) => {
    const map = useMap();
    useEffect(() => {
        if (location) map.flyTo(location, 13);
    }, [location, map]);
    return null;
};
const Dashboard = () => {
    const [providers, setProviders] = useState([]);
    const [loading, setLoading] = useState(true);
    const [userLocation, setUserLocation] = useState([13.0827, 80.2707]); // Default: Chennai

    // Fetch user location
    useEffect(() => {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    setUserLocation([position.coords.latitude, position.coords.longitude]);
                },
                (error) => console.error("Error getting location:", error)
            );
        }
    }, []);

    // Fetch nearby services
    useEffect(() => {
        const timer1 = setTimeout(() => setLoading(true), 0);
        const timer2 = setTimeout(() => {
            setProviders([
                { id: 1, name: "Ramesh Electrician", category: "Electrician", distance: "1.2 km", lat: userLocation[0] + 0.01, lng: userLocation[1] + 0.01 },
                { id: 2, name: "Kumar Plumbing", category: "Plumber", distance: "2.5 km", lat: userLocation[0] - 0.01, lng: userLocation[1] - 0.01 },
                { id: 3, name: "Suresh Carpentry", category: "Carpenter", distance: "3.1 km", lat: userLocation[0] + 0.02, lng: userLocation[1] - 0.01 }
            ]);
            setLoading(false);
        }, 1000);
        return () => { clearTimeout(timer1); clearTimeout(timer2); };
    }, [userLocation]);

    return (
        <div className="container py-5 mt-5">
            <div className="row mb-4">
                <div className="col-12">
                    <h2 className="fw-bold">My Dashboard</h2>
                    <p className="text-muted">Find nearby services based on your current location.</p>
                </div>
            </div>

            <div className="row g-4">
                {/* Map Column */}
                <div className="col-lg-8">
                    <div className="card shadow-sm border-0 rounded-4 h-100">
                        <div className="card-header bg-white border-0 pt-4 pb-0">
                            <h5 className="fw-bold mb-0"><i className="fas fa-map-marked-alt text-primary me-2"></i> Service Map</h5>
                        </div>
                        <div className="card-body p-3">
                            <div className="rounded-3 bg-light overflow-hidden" style={{ height: "500px", width: "100%", zIndex: 1 }}>
                                <MapContainer center={userLocation} zoom={13} style={{ height: "100%", width: "100%" }}>
                                    <TileLayer
                                        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                                        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                                    />
                                    <RecenterMap location={userLocation} />

                                    {/* User Marker */}
                                    <Marker position={userLocation}>
                                        <Popup>You are here</Popup>
                                    </Marker>

                                    {/* Provider Markers */}
                                    {providers.map(p => (
                                        <Marker key={p.id} position={[p.lat, p.lng]}>
                                            <Popup>
                                                <strong>{p.name}</strong><br />
                                                {p.category} ({p.distance})
                                            </Popup>
                                        </Marker>
                                    ))}
                                </MapContainer>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Nearby Services Column */}
                <div className="col-lg-4">
                    <div className="card shadow-sm border-0 rounded-4 h-100">
                        <div className="card-header bg-white border-0 pt-4 pb-0 d-flex justify-content-between align-items-center">
                            <h5 className="fw-bold mb-0"><i className="fas fa-list text-primary me-2"></i> Nearby</h5>
                            <select className="form-select w-auto form-select-sm" id="nearbyServiceFilter" defaultValue="all">
                                <option value="all">All Services</option>
                                <option value="electrician">Electrician</option>
                                <option value="plumber">Plumber</option>
                                <option value="carpenter">Carpenter</option>
                                <option value="ac mechanic">AC Mechanic</option>
                            </select>
                        </div>
                        <div className="card-body p-0 mt-3" style={{ maxHeight: "500px", overflowY: "auto" }}>
                            <ul className="list-group list-group-flush" id="nearbyProvidersList">
                                {loading && (
                                    <li className="list-group-item p-4 text-center text-muted">
                                        <div className="spinner-border text-primary spinner-border-sm me-2" role="status"></div>
                                        Finding nearby services...
                                    </li>
                                )}
                                {!loading && providers.map(p => (
                                    <li key={p.id} className="list-group-item p-0">
                                        <Link to={`/provider-details?id=${p.id}`} className="d-block p-3 text-decoration-none text-dark">
                                            <div className="d-flex justify-content-between align-items-center">
                                                <div>
                                                    <h6 className="mb-1 fw-bold">{p.name}</h6>
                                                    <small className="text-muted">{p.category}</small>
                                                </div>
                                                <span className="badge bg-primary rounded-pill">{p.distance}</span>
                                            </div>
                                        </Link>
                                    </li>
                                ))}
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Dashboard;
