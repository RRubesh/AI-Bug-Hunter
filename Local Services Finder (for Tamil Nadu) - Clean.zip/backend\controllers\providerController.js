const Provider = require('../models/Provider');

// @desc    Get all providers or filter by serviceType
// @route   GET /api/providers
// @access  Public
exports.getProviders = async (req, res) => {
    try {
        const { serviceType } = req.query;
        let query = {};
        if (serviceType && serviceType !== 'all') {
            query.serviceType = { $regex: new RegExp(serviceType, 'i') };
        }

        const providers = await Provider.find(query).populate('user', 'name email phone');
        res.json(providers);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
};

// @desc    Get a single provider by ID
// @route   GET /api/providers/:id
// @access  Public
exports.getProviderById = async (req, res) => {
    try {
        const provider = await Provider.findById(req.params.id).populate('user', 'name email phone');
        if (!provider) {
            return res.status(404).json({ message: 'Provider not found' });
        }
        res.json(provider);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
};

// @desc    Get providers within a certain radius
// @route   GET /api/providers/nearby?lng=...&lat=...&radius=...
// @access  Public
exports.getNearbyProviders = async (req, res) => {
    try {
        const { lng, lat, radius, serviceType } = req.query;

        if (!lng || !lat) {
            return res.status(400).json({ message: 'Please provide lng and lat' });
        }

        // Default radius to 10 kilometers if not provided
        const radiusInKm = radius ? parseFloat(radius) : 10;

        // Geospatial query
        let query = {
            location: {
                $near: {
                    $geometry: {
                        type: 'Point',
                        coordinates: [parseFloat(lng), parseFloat(lat)]
                    },
                    $maxDistance: radiusInKm * 1000 // Convert km to meters
                }
            }
        };

        if (serviceType && serviceType !== 'all') {
            query.serviceType = { $regex: new RegExp(serviceType, 'i') };
        }

        const providers = await Provider.find(query).populate('user', 'name phone');
        res.json(providers);

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
};
