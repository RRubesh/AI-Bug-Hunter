import { useState, useEffect } from "react";
import { Link, useSearchParams } from "react-router-dom";


const Services = () => {
    const [searchParams] = useSearchParams();
    const [allProviders, setAllProviders] = useState([]);
    const [providers, setProviders] = useState([]);
    const [selectedLocation, setSelectedLocation] = useState("");
    const [selectedCategory, setSelectedCategory] = useState("");
    const [loading, setLoading] = useState(true);

    // Fetch real data from MongoDB
    useEffect(() => {
        const fetchProviders = async () => {
            try {
                const res = await fetch('http://localhost:5000/api/providers');
                const data = await res.json();
                if (res.ok) {
                    setAllProviders(data);

                    // Check URL params to apply initial filter
                    const cat = searchParams.get('category');
                    if (cat) {
                        const properFormat = {
                            'electrician': 'Electrician',
                            'plumber': 'Plumber',
                            'carpenter': 'Carpenter',
                            'ac': 'AC Mechanic'
                        }[cat.toLowerCase()] || cat;

                        setSelectedCategory(properFormat);
                        setProviders(data.filter(p => p.serviceType === properFormat));
                    } else {
                        setProviders(data);
                    }
                }
            } catch (err) {
                console.error("Failed to fetch providers:", err);
            } finally {
                setLoading(false);
            }
        };
        fetchProviders();
    }, [searchParams]);



    const handleFilter = (e) => {
        e.preventDefault();
        let filtered = allProviders;
        if (selectedLocation) {
            filtered = filtered.filter(p => p.city && p.city.toLowerCase() === selectedLocation.toLowerCase());
        }
        if (selectedCategory) {
            filtered = filtered.filter(p => p.serviceType && p.serviceType.toLowerCase() === selectedCategory.toLowerCase());
        }
        setProviders(filtered);
    };

    return (
        <div className="container py-5 mt-5">
            <div className="row">
                {/* Filters Sidebar */}
                <div className="col-lg-3 mb-4">
                    <div className="card shadow-sm">
                        <div className="card-header bg-white fw-bold">Filters</div>
                        <div className="card-body">
                            <form className="card-body" onSubmit={handleFilter}>
                                <div className="mb-3">
                                    <label className="form-label fw-bold">Location</label>
                                    <select
                                        className="form-select"
                                        value={selectedLocation}
                                        onChange={(e) => setSelectedLocation(e.target.value)}
                                    >
                                        <option value="">All Cities</option>
                                        <option value="Chennai">Chennai</option>
                                        <option value="Madurai">Madurai</option>
                                        <option value="Coimbatore">Coimbatore</option>
                                        <option value="Trichy">Trichy</option>
                                    </select>
                                </div>
                                <div className="mb-3">
                                    <label className="form-label fw-bold">Service Type</label>
                                    <select
                                        className="form-select"
                                        value={selectedCategory}
                                        onChange={(e) => setSelectedCategory(e.target.value)}
                                    >
                                        <option value="">All Services</option>
                                        <option value="Electrician">Electrician</option>
                                        <option value="Plumber">Plumber</option>
                                        <option value="Carpenter">Carpenter</option>
                                        <option value="AC Mechanic">AC Mechanic</option>
                                    </select>
                                </div>
                                <button type="submit" className="btn btn-primary w-100">Apply Filters</button>
                                {(selectedLocation || selectedCategory) && (
                                    <button
                                        type="button"
                                        className="btn btn-outline-secondary w-100 mt-2"
                                        onClick={() => {
                                            setSelectedLocation("");
                                            setSelectedCategory("");
                                            setProviders(allProviders);
                                        }}
                                    >
                                        Clear Filters
                                    </button>
                                )}
                            </form>
                        </div>
                    </div>
                </div>

                {/* Provider List */}
                <div className="col-lg-9">
                    <h3 className="fw-bold mb-4">Available Service Providers</h3>

                    {loading ? (
                        <div className="text-center py-5">
                            <div className="spinner-border text-primary" role="status">
                                <span className="visually-hidden">Loading...</span>
                            </div>
                        </div>
                    ) : providers.length === 0 ? (
                        <div className="alert alert-info border-0 shadow-sm text-center py-5">
                            <i className="fas fa-search fa-3x text-muted mb-3"></i>
                            <h5 className="fw-bold">No providers found.</h5>
                            <p className="mb-0">Try adjusting your filters to see more results.</p>
                        </div>
                    ) : (
                        providers.map(p => (
                            <div key={p._id} className="card mb-3 shadow-sm provider-card">
                                <div className="row g-0 align-items-center">
                                    <div className="col-md-3 text-center p-3">
                                        <img src="https://randomuser.me/api/portraits/men/32.jpg" className="img-fluid rounded-circle" alt="Provider" />
                                    </div>
                                    <div className="col-md-9">
                                        <div className="card-body">
                                            <div className="d-flex justify-content-between">
                                                <h5 className="card-title fw-bold">{p.providerName || (p.user ? p.user.name : "Provider")}</h5>
                                                <span className="badge bg-success"><i className="fas fa-star text-warning"></i> {p.averageRating > 0 ? p.averageRating.toFixed(1) : "New"}</span>
                                            </div>
                                            <p className="card-text text-muted mb-1"><i className="fas fa-map-marker-alt me-2"></i>{p.address}, {p.city}</p>
                                            <p className="card-text text-muted"><i className="fas fa-tools me-2"></i>{p.serviceType} ({p.experienceYears} Years Experience)</p>
                                            <div className="d-flex mt-3">
                                                <Link to={`/provider-details?id=${p._id}`} className="btn btn-outline-primary btn-sm me-2">View Details</Link>
                                                <Link to={`/provider-details?id=${p._id}`} className="btn btn-primary btn-sm btn-book">Book Now</Link>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        ))
                    )}
                </div>
            </div>
        </div>
    );
};

export default Services;
