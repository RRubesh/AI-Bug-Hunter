import React, { useState, useEffect } from 'react';

const AdminDashboard = () => {
    const [stats, setStats] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');

    useEffect(() => {
        const fetchStats = async () => {
            const userStr = localStorage.getItem('user');
            if (!userStr) return;
            const user = JSON.parse(userStr);

            try {
                const res = await fetch('http://localhost:5000/api/admin/stats', {
                    headers: {
                        'Authorization': `Bearer ${user.token}`
                    }
                });

                if (res.ok) {
                    const data = await res.json();
                    setStats(data);
                } else {
                    const errorData = await res.json();
                    setError(errorData.message || 'Failed to fetch statistics');
                }
            } catch (err) {
                setError('Network error. Failed to connect to backend.');
            } finally {
                setLoading(false);
            }
        };

        fetchStats();
    }, []);

    if (loading) {
        return (
            <div className="text-center mt-5">
                <div className="spinner-border text-primary" role="status">
                    <span className="visually-hidden">Loading...</span>
                </div>
            </div>
        );
    }

    if (error) {
        return <div className="alert alert-danger shadow-sm border-0">{error}</div>;
    }

    return (
        <div>
            <h2 className="fw-bold mb-4">Dashboard Overview</h2>

            {/* Metric Cards */}
            <div className="row g-4 mb-5">
                <div className="col-12 col-sm-6 col-xl-3">
                    <div className="card border-0 shadow-sm h-100">
                        <div className="card-body">
                            <div className="d-flex align-items-center justify-content-between mb-3">
                                <h6 className="text-muted mb-0 fw-bold text-uppercase">Total Customers</h6>
                                <div className="bg-primary bg-opacity-10 text-primary rounded p-2 d-flex align-items-center justify-content-center" style={{ width: '40px', height: '40px' }}>
                                    <i className="fas fa-users"></i>
                                </div>
                            </div>
                            <h2 className="fw-bold mb-0">{stats?.users || 0}</h2>
                        </div>
                    </div>
                </div>
                <div className="col-12 col-sm-6 col-xl-3">
                    <div className="card border-0 shadow-sm h-100">
                        <div className="card-body">
                            <div className="d-flex align-items-center justify-content-between mb-3">
                                <h6 className="text-muted mb-0 fw-bold text-uppercase">Active Providers</h6>
                                <div className="bg-success bg-opacity-10 text-success rounded p-2 d-flex align-items-center justify-content-center" style={{ width: '40px', height: '40px' }}>
                                    <i className="fas fa-user-tie"></i>
                                </div>
                            </div>
                            <h2 className="fw-bold mb-0">{stats?.providers || 0}</h2>
                        </div>
                    </div>
                </div>
                <div className="col-12 col-sm-6 col-xl-3">
                    <div className="card border-0 shadow-sm h-100">
                        <div className="card-body">
                            <div className="d-flex align-items-center justify-content-between mb-3">
                                <h6 className="text-muted mb-0 fw-bold text-uppercase">Pending Bookings</h6>
                                <div className="bg-warning bg-opacity-10 text-warning rounded p-2 d-flex align-items-center justify-content-center" style={{ width: '40px', height: '40px' }}>
                                    <i className="fas fa-clock"></i>
                                </div>
                            </div>
                            <h2 className="fw-bold mb-0">{stats?.bookings?.pending || 0}</h2>
                        </div>
                    </div>
                </div>
                <div className="col-12 col-sm-6 col-xl-3">
                    <div className="card border-0 shadow-sm h-100">
                        <div className="card-body">
                            <div className="d-flex align-items-center justify-content-between mb-3">
                                <h6 className="text-muted mb-0 fw-bold text-uppercase">Completed Bookings</h6>
                                <div className="bg-info bg-opacity-10 text-info rounded p-2 d-flex align-items-center justify-content-center" style={{ width: '40px', height: '40px' }}>
                                    <i className="fas fa-check-circle"></i>
                                </div>
                            </div>
                            <h2 className="fw-bold mb-0">{stats?.bookings?.completed || 0}</h2>
                        </div>
                    </div>
                </div>
            </div>

            {/* Platform Stats Panel */}
            <div className="row bg-white rounded shadow-sm p-4 mx-0">
                <div className="col-md-6 mb-4 mb-md-0 border-end border-light">
                    <h5 className="fw-bold mb-3"><i className="fas fa-chart-pie text-primary me-2"></i>Platform Health</h5>
                    <p className="text-muted">The system is currently fully operational holding a total of <strong>{stats?.bookings?.total || 0}</strong> historical bookings.</p>
                </div>
                <div className="col-md-6">
                    <h5 className="fw-bold mb-3"><i className="fas fa-wallet text-success me-2"></i>Estimated Transaction Volume</h5>
                    <h2 className="text-success fw-bold">₹{stats?.revenue ? stats.revenue.toLocaleString() : "0"}</h2>
                    <p className="text-muted small">Based on combined visiting charges of all Completed bookings.</p>
                </div>
            </div>
        </div>
    );
};

export default AdminDashboard;
