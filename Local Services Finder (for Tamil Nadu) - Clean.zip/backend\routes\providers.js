const express = require('express');
const router = express.Router();
const { getProviders, getProviderById, getNearbyProviders } = require('../controllers/providerController');

// Make sure /nearby comes before /:id so it doesn't get treated as an ID
router.get('/nearby', getNearbyProviders);
router.get('/', getProviders);
router.get('/:id', getProviderById);

module.exports = router;
