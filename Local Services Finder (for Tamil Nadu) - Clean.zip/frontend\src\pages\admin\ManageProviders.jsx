import React, { useState, useEffect } from 'react';

const ManageProviders = () => {
    const [providers, setProviders] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');

    useEffect(() => {
        const fetchProviders = async () => {
            const userStr = localStorage.getItem('user');
            if (!userStr) return;
            const adminUser = JSON.parse(userStr);

            try {
                const res = await fetch('http://localhost:5000/api/admin/providers', {
                    headers: { 'Authorization': `Bearer ${adminUser.token}` }
                });

                if (res.ok) {
                    const data = await res.json();
                    setProviders(data);
                } else {
                    setError('Failed to fetch providers');
                }
            } catch (err) {
                setError('Network error.');
            } finally {
                setLoading(false);
            }
        };

        fetchProviders();
    }, []);

    if (loading) return <div className="text-center mt-5"><div className="spinner-border text-primary" role="status"></div></div>;
    if (error) return <div className="alert alert-danger">{error}</div>;

    return (
        <div className="bg-white rounded shadow-sm p-4">
            <h4 className="fw-bold mb-4">Manage Providers</h4>
            <div className="table-responsive">
                <table className="table table-hover align-middle">
                    <thead className="table-light">
                        <tr>
                            <th>Provider Name</th>
                            <th>Service Type</th>
                            <th>City</th>
                            <th>Experience</th>
                            <th>Status</th>
                            <th>Rating</th>
                        </tr>
                    </thead>
                    <tbody>
                        {providers.map(p => (
                            <tr key={p._id}>
                                <td>
                                    <div className="fw-bold">{p.providerName}</div>
                                    <div className="text-muted small">{p.user?.email}</div>
                                </td>
                                <td><span className="badge bg-secondary">{p.serviceType}</span></td>
                                <td>{p.city}</td>
                                <td>{p.experienceYears} Years</td>
                                <td>
                                    <span className={`badge ${p.availabilityStatus === 'Available' ? 'bg-success' : 'bg-warning'}`}>
                                        {p.availabilityStatus}
                                    </span>
                                </td>
                                <td>
                                    <span className="text-warning me-1"><i className="fas fa-star"></i></span>
                                    {p.averageRating} ({p.reviewCount})
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                {providers.length === 0 && <p className="text-center text-muted my-4">No providers found.</p>}
            </div>
        </div>
    );
};

export default ManageProviders;
