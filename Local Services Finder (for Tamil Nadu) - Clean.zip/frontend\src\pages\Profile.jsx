import { useState } from "react";

const Profile = () => {
    const [profile, setProfile] = useState(() => {
        const raw = localStorage.getItem('ns_profile');
        const def = { fullName: '', email: '', phone: '', address: '' };
        if (raw) {
            try { return { ...def, ...JSON.parse(raw) }; } catch { /* ignore parsing errors */ }
        }
        return def;
    });
    const [photo, setPhoto] = useState(() => localStorage.getItem('ns_profile_photo') || "/assets/images/namma-service-logo.png");
    const [hasPhoto, setHasPhoto] = useState(() => !!localStorage.getItem('ns_profile_photo'));

    const handleChange = (e) => {
        const { name, value } = e.target;
        setProfile(prev => ({ ...prev, [name]: value }));
    };

    const handleSave = (e) => {
        e.preventDefault();
        localStorage.setItem('ns_profile', JSON.stringify(profile));
        alert('Profile saved locally');
    };

    const handlePhotoUpload = (e) => {
        const file = e.target.files && e.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = function (ev) {
            const dataUrl = ev.target.result;
            setPhoto(dataUrl);
            setHasPhoto(true);
            localStorage.setItem('ns_profile_photo', dataUrl);
        };
        reader.readAsDataURL(file);
    };

    const handlePhotoRemove = () => {
        localStorage.removeItem('ns_profile_photo');
        setPhoto("/assets/images/namma-service-logo.png");
        setHasPhoto(false);
    };

    return (
        <div className="container py-5 mt-5">
            <div className="row">
                <div className="col-md-8 mx-auto">
                    <div className="card shadow-sm border-0 rounded-4">
                        <div className="card-header bg-white border-0 py-4">
                            <h4 className="mb-0 fw-bold"><i className="fas fa-user me-2 text-primary"></i>My Profile</h4>
                        </div>
                        <div className="card-body">
                            <form onSubmit={handleSave}>
                                <div className="mb-4 d-flex align-items-center gap-4">
                                    <div className="profile-photo text-center">
                                        <img src={photo} alt="Profile Photo" className="rounded-circle" style={{ width: "100px", height: "100px", objectFit: "cover", border: "2px solid #e9ecef" }} />
                                        <div className="mt-2">
                                            {hasPhoto && <button type="button" onClick={handlePhotoRemove} className="btn btn-sm btn-outline-danger">Remove</button>}
                                        </div>
                                    </div>
                                    <div className="flex-grow-1">
                                        <label className="form-label mb-1">Profile Photo</label>
                                        <input type="file" accept="image/*" onChange={handlePhotoUpload} className="form-control form-control-sm" />
                                        <small className="text-muted">Upload a square photo for best results (JPG/PNG).</small>
                                    </div>
                                </div>

                                <div className="mb-3">
                                    <label className="form-label">Full Name</label>
                                    <input type="text" className="form-control" name="fullName" value={profile.fullName} onChange={handleChange} placeholder="Enter your name" />
                                </div>
                                <div className="mb-3">
                                    <label className="form-label">Email</label>
                                    <input type="email" className="form-control" name="email" value={profile.email} onChange={handleChange} placeholder="you@example.com" />
                                </div>
                                <div className="mb-3">
                                    <label className="form-label">Phone</label>
                                    <input type="tel" className="form-control" name="phone" value={profile.phone} onChange={handleChange} placeholder="Mobile number" />
                                </div>
                                <div className="mb-3">
                                    <label className="form-label">Address</label>
                                    <textarea className="form-control" name="address" rows="2" value={profile.address} onChange={handleChange} placeholder="Your address"></textarea>
                                </div>
                                <div className="d-flex justify-content-end">
                                    <button type="submit" className="btn btn-primary">Save Changes</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Profile;
