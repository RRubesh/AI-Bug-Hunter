import React, { useState, useEffect } from 'react';

const ManageUsers = () => {
    const [users, setUsers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');

    useEffect(() => {
        const fetchUsers = async () => {
            const userStr = localStorage.getItem('user');
            if (!userStr) return;
            const adminUser = JSON.parse(userStr);

            try {
                const res = await fetch('http://localhost:5000/api/admin/users', {
                    headers: { 'Authorization': `Bearer ${adminUser.token}` }
                });

                if (res.ok) {
                    const data = await res.json();
                    setUsers(data);
                } else {
                    setError('Failed to fetch users');
                }
            } catch (err) {
                setError('Network error.');
            } finally {
                setLoading(false);
            }
        };

        fetchUsers();
    }, []);

    if (loading) return <div className="text-center mt-5"><div className="spinner-border text-primary" role="status"></div></div>;
    if (error) return <div className="alert alert-danger">{error}</div>;

    return (
        <div className="bg-white rounded shadow-sm p-4">
            <h4 className="fw-bold mb-4">Manage Users</h4>
            <div className="table-responsive">
                <table className="table table-hover align-middle">
                    <thead className="table-light">
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Role</th>
                            <th>Joined Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        {users.map(u => (
                            <tr key={u._id}>
                                <td>
                                    <div className="d-flex align-items-center">
                                        <div className="bg-primary bg-opacity-10 text-primary rounded-circle d-flex justify-content-center align-items-center me-3" style={{ width: '35px', height: '35px' }}>
                                            {u.name.charAt(0).toUpperCase()}
                                        </div>
                                        <span className="fw-bold">{u.name}</span>
                                    </div>
                                </td>
                                <td>{u.email}</td>
                                <td>{u.phone || 'N/A'}</td>
                                <td>
                                    <span className={`badge ${u.role === 'admin' ? 'bg-danger' : u.role === 'provider' ? 'bg-success' : 'bg-primary'}`}>
                                        {u.role}
                                    </span>
                                </td>
                                <td>{new Date(u.createdAt).toLocaleDateString()}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                {users.length === 0 && <p className="text-center text-muted my-4">No users found.</p>}
            </div>
        </div>
    );
};

export default ManageUsers;
